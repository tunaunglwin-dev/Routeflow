let orders = 125;
let vehicles = 18;
let drivers = 24;

function logActivity(text){

const li = document.createElement("li");

li.className = "list-group-item";

li.innerText =
new Date().toLocaleTimeString()
+ " - "
+ text;

document
.getElementById("feed")
.prepend(li);

}

function addOrder(){

orders++;

document.getElementById("orders").innerText = orders;

logActivity("New Order Added");

}

function addVehicle(){

vehicles++;

document.getElementById("vehicles").innerText = vehicles;

logActivity("Vehicle Added");

}

function completeDelivery(){

logActivity("Delivery Completed");

}

const ctx =
document
.getElementById("deliveryChart");

new Chart(ctx,{

type:"bar",

data:{

labels:[
"Mon",
"Tue",
"Wed",
"Thu",
"Fri",
"Sat",
"Sun"
],

datasets:[{

label:"Deliveries",

data:[
35,
52,
48,
65,
70,
90,
80
]

}]

}

});